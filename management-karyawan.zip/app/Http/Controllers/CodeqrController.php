<?php

namespace App\Http\Controllers;

use App\Models\Codeqr;
use App\Http\Requests\StoreCodeqrRequest;
use App\Http\Requests\UpdateCodeqrRequest;

class CodeqrController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCodeqrRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Codeqr $codeqr)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Codeqr $codeqr)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCodeqrRequest $request, Codeqr $codeqr)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Codeqr $codeqr)
    {
        //
    }
}
